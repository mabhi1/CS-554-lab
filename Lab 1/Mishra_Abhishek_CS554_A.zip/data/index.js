const blog = require("./blog");
const user = require("./user");

module.exports = {
    blog,
    user,
};
